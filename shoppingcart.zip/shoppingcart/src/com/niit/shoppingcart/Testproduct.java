package com.niit.shoppingcart;

public class Testproduct {
	public static void main(String[] args) {
		Product product=new Product();
		product.setId("PRD100");
		product.setName("mobile product");
		product.setPrice(-15000);

		
		
		System.out.println(product.getId());
		System.out.println(product.getName());
		System.out.println(product.getPrice());
	}

}
